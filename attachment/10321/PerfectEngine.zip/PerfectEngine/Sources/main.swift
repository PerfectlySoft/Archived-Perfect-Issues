import PerfectLib
import PerfectHTTP
import PerfectHTTPServer
import PerfectThread
import PerfectCURL
import cURL

let filterHost = "127.0.0.1"
let filterPort = 8080

public func restGet(url: String, completion: @escaping ([UInt8]?)->Void ) {
  Threading.dispatch {
    let curl = CURL(url: url)
    let _ = curl.setOption(CURLOPT_TIMEOUT, int: 10)
    let (code, _, body) = curl.performFully()
    completion((code > -1 && body.count > 0) ? body : nil)
    curl.close()
  }
}

public func restPost(url: String, bytes: [UInt8], completion: @escaping ([UInt8]?)->Void ) {
  Threading.dispatch {
    let curl = CURL(url: url)
    let _ = curl.setOption(CURLOPT_TIMEOUT, int: 10)
    let _ = curl.setOption(CURLOPT_POST, int: 1)
    let _ = curl.setOption(CURLOPT_POSTFIELDS, v: UnsafeMutableRawPointer(mutating:bytes))
    let _ = curl.setOption(CURLOPT_POSTFIELDSIZE, int: bytes.count)
    let (code, _, body) = curl.performFully()
    completion((code > -1 && body.count > 0) ? body : nil)
    curl.close()
  }
}

func getProcess(data: [String:Any]) throws -> RequestHandler {
  return {
    request, response in
    restGet(url: "http://\(filterHost):\(filterPort)/getProcess") { body in
      response.setHeader(.contentType, value: "application/json")
      response.appendBody(bytes: body != nil ? body! : [])
      response.completed()
    }
  }
}

func postProcess(data: [String:Any]) throws -> RequestHandler {
  return {
    request, response in
    
    restPost(url: "http://\(filterHost):\(filterPort)/postProcess", bytes: request.postBodyBytes!){ body in
      response.setHeader(.contentType, value: "application/json")
      response.appendBody(bytes: body != nil ? body! : [])
      response.completed()
    }
  }
}

// Routing

let port = 8888

let confData = [
	"servers": [
		[
			"name":"localhost",
			"port":port,
			"routes":[
				["method":"get", "uri":"/getProcess", "handler":getProcess],
				["method":"post", "uri":"/postProcess", "handler":postProcess]
			],
		]
	]
]

do {
	try HTTPServer.launch(configurationData: confData)
}
catch {
	fatalError("\(error)") // fatal error launching one of the servers
}

/*
 Hello, I made some modification with my code, I though that maybe doing the Get call to the sub service in sync while handling the call from the client was the culprit… but I get the same kind of very bad performances.
 One of the typical symptom is the way a client can feed the sub service with enough messages to keep it very buzy.

 TestHarnessProcess

 */
