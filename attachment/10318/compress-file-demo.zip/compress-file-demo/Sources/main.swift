import PerfectLib
import PerfectHTTP
import PerfectHTTPServer
import Foundation


var routes = Routes()

routes.add(method: .get, uri: "/") { (request, response) in
    response.returnWithJSONMessage(message: "Hey there!")
}

routes.add(method: .get, uri: "/hey/{name}") { (request, response) in
    response.returnWithJSONMessage(message: "Hey \(request.urlVariables["name"] ?? "Stranger")!")
}

let server = HTTPServer()
server.documentRoot = "webroot"
server.serverPort = 8080
server.serverAddress = "0.0.0.0"

server.addRoutes(routes)

if let filter = try? HTTPFilter.contentCompression(data:[:]) {
    server.setResponseFilters([(filter, .high)])
}

do {
    try server.start()
} catch {
    fatalError("\(error)")
}

