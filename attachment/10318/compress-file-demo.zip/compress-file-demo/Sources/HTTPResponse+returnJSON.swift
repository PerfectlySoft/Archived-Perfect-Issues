//
//  HTTPResponse+returnJSON.swift
//  mobile-backend
//
//  Created by Dan Pashchenko on 3/19/17.
//
//

import Foundation
import PerfectHTTP
import PerfectLib

extension HTTPResponse
{
    func returnWithJSON(json:Dictionary<String, Any>)
    {
        setHeader(.contentType, value: "application/json")
        do { try setBody(json: json) }
        catch { setBody(string: "Error: \(error)") }
        completed()
    }
    
    func returnWithJSONMessage(message:String) {
        returnWithJSON(json: ["message" : message])
    }
}
