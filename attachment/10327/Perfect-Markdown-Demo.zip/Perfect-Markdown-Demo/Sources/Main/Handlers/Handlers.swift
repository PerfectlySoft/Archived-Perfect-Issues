//
//  Handlers.swift
//  Perfect-App-Template
//
//  Created by Jonathan Guthrie on 2017-02-20.
//	Copyright (C) 2017 PerfectlySoft, Inc.
//
//===----------------------------------------------------------------------===//
//
// This source file is part of the Perfect.org open source project
//
// Copyright (c) 2015 - 2016 PerfectlySoft Inc. and the Perfect project authors
// Licensed under Apache License v2.0
//
// See http://perfect.org/licensing.html for license information
//
//===----------------------------------------------------------------------===//
//

import Foundation
import PerfectLib
import PerfectHTTP
import PerfectMarkdown

class Handlers {

	// Basic "main" handler - simply outputs "Hello, world!"
	static func main(data: [String:Any]) throws -> RequestHandler {
		return {
			request, response in
			response.setBody(string: "<html><title>Hello, world!</title><body>Hello, world!</body></html>")
			response.completed()
		}
	}
    
    /// api Listing input Markdown output HTML
    static func apiHandler(data: [String:Any]) throws -> RequestHandler {
        
        return {
            request, response in
            
            //        let name = request.urlVariables["name"] ?? "api"
            
            // Read MarkdownDoc
            let thisFile = File("./ApiDoc/api_en.md")
//            let thisFile = File("./ApiDoc/api.md")
            
            do {
                try thisFile.open(.read)
            } catch {
                response.status = .internalServerError
                response.appendBody(string: "\(error)")
                response.completed()
            }
            
            defer {
                thisFile.close()
            }
            
            do {
                let markdown = try thisFile.readString()
                // Respond with a simple message.
                response.setHeader(.contentType, value: "text/html")
                let html = markdown.markdownToHTML ?? "Markdown to HTML Failed"
                let output = html.contains(string: "<table>") ? html.replacingOccurrences(of: "<table>", with: "<div class=\"table-responsive\"><table class=\"table table-striped\">") : html
                
                print(html)
                
                //MARK: import bootstrap style
                response.appendBody(string: "<HTML><meta http-equiv='Content-Type' content='text/html;charset=utf-8'><head><link rel=\"stylesheet\" href=\"https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css\"></head><body style=\"padding:30px\"><H1>Markdown API DOC</H1>\(output)</body></HTML>")
                
                //MARK: without bootstrap style
//                response.appendBody(string: "<HTML><meta http-equiv='Content-Type' content='text/html;charset=utf-8'><body>\(output)</body></HTML>")
                
                // Ensure that response.completed() is called when your processing is done.
                response.completed()
                
            } catch {
                response.status = .internalServerError
                response.appendBody(string: "\(error)")
                response.completed()
            }
        }
    }
    
}
