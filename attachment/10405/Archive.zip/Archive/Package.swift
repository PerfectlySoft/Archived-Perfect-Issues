// Generated automatically by Perfect Assistant Application
// Date: 2017-07-16 21:25:14 +0000
import PackageDescription
let package = Package(
	name: "Routing",
	targets: [],
	dependencies: [
		.Package(url: "https://github.com/PerfectlySoft/Perfect-HTTPServer.git", majorVersion: 2),
	]
)
