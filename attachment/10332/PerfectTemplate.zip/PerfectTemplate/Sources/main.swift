//
//  main.swift
//  PerfectTemplate
//
//  Created by Kyle Jessup on 2015-11-05.
//	Copyright (C) 2015 PerfectlySoft, Inc.
//
//===----------------------------------------------------------------------===//
//
// This source file is part of the Perfect.org open source project
//
// Copyright (c) 2015 - 2016 PerfectlySoft Inc. and the Perfect project authors
// Licensed under Apache License v2.0
//
// See http://perfect.org/licensing.html for license information
//
//===----------------------------------------------------------------------===//
//

import PerfectLib
import PerfectHTTP
import PerfectHTTPServer
import MySQL

// An example request handler.
// This 'handler' function can be referenced directly in the configuration below.
func handler(data: [String:Any]) throws -> RequestHandler {
    return {
        request, response in
        
        
        
        let testHost = "127.0.0.1"
        let testUser = "root"
        let testPassword = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        let testSchema = "quickTest"
        
        let dataMysql = MySQL()
        
        guard dataMysql.connect(host: testHost, user: testUser, password: testPassword ) else {
            Log.info(message: "Failure connecting to data server \(testHost)")
            return
        }
        
        defer {
            dataMysql.close()  // defer ensures we close our db connection at the end of this request
        }
        
        //set database to be used, this example assumes presence of a users table and run a raw query, return failure message on a error
        if !dataMysql.selectDatabase(named: testSchema) {
            let q = "CREATE SCHEMA \(testSchema) DEFAULT CHARACTER SET utf8mb4;"
            guard dataMysql.query(statement: q) else {
                Log.info(message: dataMysql.errorMessage())
                return
            }
            
            guard dataMysql.selectDatabase(named: testSchema) else {
                Log.info(message: "Failure: \(dataMysql.errorCode()) \(dataMysql.errorMessage())")
                
                return
            }
        }
        
        let q = "CREATE TABLE IF NOT EXISTS Test (id INT AUTO_INCREMENT PRIMARY KEY)"
        guard dataMysql.query(statement: q) else {
            Log.info(message: dataMysql.errorMessage())
            return
        }
        
        let stmt = MySQLStmt(dataMysql)
        
        guard stmt.prepare(statement: "SELECT * FROM Test WHERE id = ?") else {
            Log.info(message: "unable to prepare: \(stmt.errorMessage())")
            stmt.close()
            return
        }
        
        stmt.bindParam(1)
        stmt.bindParam(1)
        
        _ = stmt.execute()
        
        stmt.close()
        
        
        
        response.completed()
    }
}

// Configuration data for two example servers.
// This example configuration shows how to launch one or more servers
// using a configuration dictionary.

let port1 = 8080, port2 = 8181

let confData = [
    "servers": [
        // Configuration data for one server which:
        //	* Serves the hello world message at <host>:<port>/
        //	* Serves static files out of the "./webroot"
        //		directory (which must be located in the current working directory).
        //	* Performs content compression on outgoing data when appropriate.
        [
            "name":"localhost",
            "port":port1,
            "routes":[
                ["method":"get", "uri":"/", "handler":handler],
                ["method":"get", "uri":"/**", "handler":PerfectHTTPServer.HTTPHandler.staticFiles,
                 "documentRoot":"./webroot",
                 "allowResponseFilters":true]
            ],
            "filters":[
                [
                    "type":"response",
                    "priority":"high",
                    "name":PerfectHTTPServer.HTTPFilter.contentCompression,
                    ]
            ]
        ],
        // Configuration data for another server which:
        //	* Redirects all traffic back to the first server.
        [
            "name":"localhost",
            "port":port2,
            "routes":[
                ["method":"get", "uri":"/**", "handler":PerfectHTTPServer.HTTPHandler.redirect,
                 "base":"http://localhost:\(port1)"]
            ]
        ]
    ]
]

do {
    // Launch the servers based on the configuration data.
    try HTTPServer.launch(configurationData: confData)
} catch {
    fatalError("\(error)") // fatal error launching one of the servers
}

