//
//  main.swift
//  PerfectTemplate
//
//  Created by Kyle Jessup on 2015-11-05.
//	Copyright (C) 2015 PerfectlySoft, Inc.
//
//===----------------------------------------------------------------------===//
//
// This source file is part of the Perfect.org open source project
//
// Copyright (c) 2015 - 2016 PerfectlySoft Inc. and the Perfect project authors
// Licensed under Apache License v2.0
//
// See http://perfect.org/licensing.html for license information
//
//===----------------------------------------------------------------------===//
//

import PerfectLib
import PerfectHTTP
import PerfectHTTPServer
import PerfectCURL
import cURL

class DeinitCURL: CURL {
    deinit {
        print("removing CURL request from memory")
    }
}

extension DeinitCURL {
    convenience init(completion: @escaping(Int, [UInt8], [UInt8], CURL) -> Void) {
        self.init()
        self.url = "https://www.google.com"
        self.setOption(CURLOPT_TIMEOUT, int: 1) // set the timeout to 5 seconds
        self.perform() { tuple in
            completion(tuple.0, tuple.1, tuple.2, self)
        }
    }
}


// Create HTTP server.
let server = HTTPServer()

let numberRequests = 100

// Register your own routes and handlers
var routes = Routes()
routes.add(method: .get, uri: "/reset", handler: { request, response in
    response.setHeader(.contentType, value: "text/html")
    response.appendBody(string: "<html><title>Hello, world!</title><body>Hello, world!</body></html>")
    response.completed()
    for i in 0 ..< numberRequests {
        let request = DeinitCURL(completion: { (code, header, body, returnedCURLObject) in
            returnedCURLObject.reset()
        })
    }
})

routes.add(method: .get, uri: "/resetclose", handler: { request, response in
    response.setHeader(.contentType, value: "text/html")
    response.appendBody(string: "<html><title>Hello, world!</title><body>Hello, world!</body></html>")
    response.completed()
    for i in 0 ..< numberRequests {
        let request = DeinitCURL(completion: { (code, header, body, returnedCURLObject) in
            returnedCURLObject.reset()
            returnedCURLObject.close()
        })
    }
})

routes.add(method: .get, uri: "/close", handler: { request, response in
    response.setHeader(.contentType, value: "text/html")
    response.appendBody(string: "<html><title>Hello, world!</title><body>Hello, world!</body></html>")
    response.completed()
    for i in 0 ..< numberRequests {
        let request = DeinitCURL(completion: { (code, header, body, returnedCURLObject) in
            returnedCURLObject.close()
        })
    }
})

routes.add(method: .get, uri: "/nothing", handler: { request, response in
    response.setHeader(.contentType, value: "text/html")
    response.appendBody(string: "<html><title>Hello, world!</title><body>Hello, world!</body></html>")
    response.completed()
    for i in 0 ..< numberRequests {
        let request = DeinitCURL(completion: { (code, header, body, returnedCURLObject) in
            // do nothing
        })
    }
})

// Add the routes to the server.
server.addRoutes(routes)

// Set a listen port of 8181
server.serverPort = 8181

// Set a document root.
// This is optional. If you do not want to serve static content then do not set this.
// Setting the document root will automatically add a static file handler for the route /**
server.documentRoot = "./webroot"

// Gather command line options and further configure the server.
// Run the server with --help to see the list of supported arguments.
// Command line arguments will supplant any of the values set above.
configureServer(server)

do {
	// Launch the HTTP server.
	try server.start()
} catch PerfectError.networkError(let err, let msg) {
	print("Network error thrown: \(err) \(msg)")
}
